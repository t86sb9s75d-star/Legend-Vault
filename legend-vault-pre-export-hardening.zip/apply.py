#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import shutil
import sys


def replace_exact(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    if old not in text:
        raise RuntimeError(
            f"Expected text was not found in {path}. "
            "The repository may have changed since this package was built."
        )
    path.write_text(text.replace(old, new, 1), encoding="utf-8", newline="\n")


def main() -> int:
    package_root = Path(__file__).resolve().parent
    payload = package_root / "payload"
    repo = Path.cwd().resolve()

    if not (repo / "pyproject.toml").exists():
        raise RuntimeError(
            "Run this script from the Legend Vault repository root."
        )

    for source in sorted(payload.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(payload)
        target = repo / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        print(f"installed {relative.as_posix()}")

    synthetic_test = repo / "tests" / "test_synthetic_end_to_end.py"
    old_main = '''if __name__ == "__main__":
    test_synthetic_import_verify_and_diff()
    print("Synthetic end-to-end test passed.")
'''
    new_main = '''if __name__ == "__main__":
    test_synthetic_import_verify_and_diff()

    from test_verifier_fault_injection import test_fault_injection_suite

    test_fault_injection_suite()
    print("Synthetic end-to-end and verifier fault-injection tests passed.")
'''
    replace_exact(synthetic_test, old_main, new_main)

    status = repo / "docs" / "STATUS.md"
    replace_exact(
        status,
        "- Synthetic end-to-end test\n",
        "- Synthetic end-to-end test\n"
        "- Verifier fault-injection regression suite\n",
    )

    readme = repo / "README.md"
    replace_exact(
        readme,
        "The Python CLI baseline is runnable and its synthetic end-to-end path is tested.\n",
        "The Python CLI baseline is runnable, and its synthetic end-to-end and\n"
        "verifier fault-injection paths are tested.\n",
    )

    print("pre-export hardening payload applied")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(
            f"apply failed: {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        raise
