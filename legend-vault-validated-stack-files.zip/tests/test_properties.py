from __future__ import annotations

import re
from typing import Any

from hypothesis import given, strategies as st

from legend_vault.core import flatten_content, normalize_actor, stable_event_id


TEXT = st.text(max_size=64)
CONTENT_HASH = st.text(min_size=1, max_size=128)
EVENT_ID_RE = re.compile(r"^evt_[0-9a-f]{32}$")


@given(
    record_id=TEXT,
    source_message_id=st.one_of(st.none(), TEXT),
    sequence=st.integers(min_value=0, max_value=2**31 - 1),
    content_hash=CONTENT_HASH,
)
def test_stable_event_id_is_deterministic(
    record_id: str,
    source_message_id: str | None,
    sequence: int,
    content_hash: str,
) -> None:
    first = stable_event_id(record_id, source_message_id, sequence, content_hash)
    second = stable_event_id(record_id, source_message_id, sequence, content_hash)

    assert first == second
    assert EVENT_ID_RE.fullmatch(first)


@given(
    record_id=TEXT,
    source_message_id=st.one_of(st.none(), TEXT),
    sequence=st.integers(min_value=0, max_value=2**31 - 2),
    content_hash=CONTENT_HASH,
)
def test_stable_event_id_changes_when_sequence_changes(
    record_id: str,
    source_message_id: str | None,
    sequence: int,
    content_hash: str,
) -> None:
    current = stable_event_id(record_id, source_message_id, sequence, content_hash)
    following = stable_event_id(record_id, source_message_id, sequence + 1, content_hash)

    assert current != following


@given(role=st.one_of(st.none(), TEXT))
def test_normalize_actor_returns_only_declared_actors(role: str | None) -> None:
    normalized = normalize_actor(role)
    allowed = {"user", "assistant", "tool", "system", "unknown"}

    assert normalized in allowed
    if role is not None and role.lower() in allowed - {"unknown"}:
        assert normalized == role.lower()
    else:
        assert normalized == "unknown"


SAFE_KEYS = st.text(min_size=1, max_size=20).filter(
    lambda key: key not in {"parts", "text"}
)
JSON_SCALARS = st.one_of(
    st.none(),
    st.booleans(),
    st.integers(),
    st.floats(allow_nan=False, allow_infinity=False),
    st.text(max_size=40),
)


@given(payload=st.dictionaries(SAFE_KEYS, JSON_SCALARS, max_size=20))
def test_flatten_content_is_stable_across_dictionary_order(
    payload: dict[str, Any],
) -> None:
    reversed_payload = dict(reversed(list(payload.items())))

    assert flatten_content(payload) == flatten_content(reversed_payload)
