# Legend Vault technology stack

## Governing rule

Legend Vault remains a raw-first archival system. A new library is not part of
the authority hierarchy merely because it is installed.

The preserved source archive and `raw/events.jsonl` remain above every parser,
embedding, graph, model, agent, dashboard, and generated summary.

## Active baseline

These components are approved for the current repository:

| Component | Role | Authority |
|---|---|---|
| Python standard library | Archive import, canonicalization, verification, and diff | Runtime core |
| pytest | Test discovery and execution | Executable evidence only |
| Hypothesis | Property-based invariant testing | Executable evidence only |
| Ruff | Correctness-focused static checks | Quality gate |
| pre-commit | Local quality gate before commits | Workflow control |
| GitHub Actions | Clean-environment CI across supported Python versions | Repeatability evidence |

Install with:

```bash
python -m pip install -e ".[dev]"
pre-commit install
```

## Optional pilot: document ingestion

### Docling

Repository: <https://github.com/docling-project/docling>

Purpose:

- parse PDFs, Office files, email, images, audio, and structured document layout;
- preserve tables, reading order, formulas, and document structure where possible;
- run locally when records are sensitive.

Install:

```bash
python -m pip install -e ".[ingestion]"
```

Gate before use:

1. Keep the original binary unchanged.
2. Store parser output as a derived layer.
3. Record parser name and version.
4. Measure omissions and transformations against known fixtures.
5. Never silently replace unavailable source material with generated text.

## Optional benchmark: memory and retrieval

Install the benchmark candidates with:

```bash
python -m pip install -e ".[memory-benchmark]"
```

### Graphiti

Repository: <https://github.com/getzep/graphiti>

Candidate role: temporal context graph with provenance and changing facts.

### Mem0

Repository: <https://github.com/mem0ai/mem0>

Candidate role: compact user, session, and agent memory retrieval.

### Qdrant

Repository: <https://github.com/qdrant/qdrant>

Candidate role: vector retrieval only after local retrieval no longer meets the
measured scale or latency requirement.

Benchmark requirements:

- identical source corpus;
- identical question set;
- recall, precision, provenance, temporal accuracy, latency, and token usage;
- named false positives and false negatives;
- no architecture decision based only on vendor benchmarks.

No memory system may alter the raw archive or canonical event stream.

## Optional pilot: agents and tools

Install with:

```bash
python -m pip install -e ".[agents]"
```

### OpenAI Agents SDK

Repository: <https://github.com/openai/openai-agents-python>

Candidate role: tool orchestration, guardrails, handoffs, human approval, and
tracing.

### Model Context Protocol SDK

Repository: <https://github.com/modelcontextprotocol/python-sdk>

Candidate role: controlled interfaces to files, databases, parsers, and other
tools.

Agent boundary:

- read-only by default;
- explicit approval before deletion, publication, export, or external writes;
- every tool call logged;
- generated interpretations labeled as derived;
- no hidden mutation of source or integrity metadata.

## Optional structured-data validation

### Pandera

Repository: <https://github.com/unionai-oss/pandera>

Install:

```bash
python -m pip install -e ".[data-validation]"
```

Use only when Legend Vault introduces dataframe-like import, calibration, or
evaluation datasets. It is not currently required by the archive core.

## Optional data exploration

### Datasette

Repository: <https://github.com/simonw/datasette>

Install:

```bash
python -m pip install -e ".[data-ui]"
```

Candidate role: read-only exploration and API access for future SQLite indexes.
It must not become a path for bypassing record verification or editing
authoritative data.

## External quality and security tools

These tools are tracked as part of the engineering stack but are intentionally
not Python project dependencies.

### Promptfoo

Repository: <https://github.com/promptfoo/promptfoo>

Use for repeatable LLM evaluations, regression checks, and red teaming before
any AI-derived feature is treated as usable.

### Betterleaks

Repository: <https://github.com/betterleaks/betterleaks>

Use to scan commits, branches, pull requests, and local files for exposed
credentials or tokens.

### Semgrep

Repository: <https://github.com/semgrep/semgrep>

Use for targeted secure-coding rules. Start with narrow, reviewed rules rather
than a noisy all-rules gate.

### No-Mistakes

Repository: <https://github.com/kunchenguid/no-mistakes>

Use only as a controlled pre-push pilot. AI-generated fixes stay disabled until
the review quality has been measured against known defects.

## Deferred product and workflow components

The following repositories remain research references, not active dependencies:

- <https://github.com/khoj-ai/khoj>
- <https://github.com/run-llama/llama_index>
- <https://github.com/Unstructured-IO/unstructured>
- <https://github.com/n8n-io/n8n>
- <https://github.com/twentyhq/twenty>
- <https://github.com/supabase/supabase>
- <https://github.com/browserbase/stagehand>
- <https://github.com/browser-use/browser-use>
- <https://github.com/alibaba/page-agent>

Each requires a concrete use case, threat model, license review, maintenance
review, and measured benefit before adoption.
